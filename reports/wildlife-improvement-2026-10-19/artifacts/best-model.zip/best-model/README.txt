Wildlife Detection — 最终选中模型

YOLO11-L, 1280 pixels + test-time augmentation. This is the validation-selected
winner among six candidates, not a Qwen adapter. No Qwen base model is needed.
Source revision: c5e74a5a3b57b90cf7df922d222c96fa3fca9274
Framework used: Python3.12, torch2.6.0+cu124, ultralytics8.3.203, NVIDIA H200.

在Linux/NVIDIA GPU机器上，将整个目录解压到登录用户home内。从解压目录运行：

mkdir -p "$HOME/.cache/wildlife-inference/tmp"
export TMPDIR="$HOME/.cache/wildlife-inference/tmp"
export TMP="$TMPDIR" TEMP="$TMPDIR"
export PIP_CACHE_DIR="$HOME/.cache/wildlife-inference/pip"
python3.12 -m venv "$HOME/.venvs/wildlife-inference"
"$HOME/.venvs/wildlife-inference/bin/python" -m pip install -r requirements-inference.txt
"$HOME/.venvs/wildlife-inference/bin/python" -m scripts.campaign.predict \
  --bundle selected_model --images "$HOME/my_images" --output "$HOME/predictions.jsonl"

输出路径必须是一个新文件；程序不会覆盖旧预测。device=0，使用第一张可见CUDA卡。
要指定另一张卡，在命令前设置CUDA_VISIBLE_DEVICES。当前入口未宣称支持Mac/CPU。
requirements固定核心依赖；未锁定全部传递依赖。完全冻结的训练环境见源码提交的uv.lock。

recipe.json保存实际选中的推理配置与官方类别映射；运行时augment=true、imgsz=1280、
conf=0.001、iou=0.6、max_det=100。预测JSONL每图一行，id为输入目录内相对路径，
detections包含category_id、bbox=[x,y,width,height]（原图像素）、score。
conf=0.001保留评价需要的低分框，不意味着全部框应直接作为产品报警。
不要把测试集结果用于重新调阈值后仍声称是本次独立测试。

完整比较与局限见comparison.html。只有验证集用于模型选择。
独立跨相机测试mAP=35.09%、AP50=52.03%、AR100=48.46%；
同相机测试mAP=46.51%、AP50=68.97%、AR100=56.66%。
两个测试集空图误报@0.5分别为4.22%（跨相机）和4.32%（同相机）。
稀有类别效果仍不稳定，单次种子，没有全球最优或部署充分验证的声明。
